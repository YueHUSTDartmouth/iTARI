#' iTARI
#' @param geneExp string
#'        tarGene string
#'        iterativeMax int
#'        setMin int
#'        corCut numeric
#'        permTimes int
#'        channel logic
#' @return refined gene set
#' @export
iTARI <- function(geneExp = "TCGA", tarGene = "MSigDB", iterativeMax = 10, setMin = 20, 
				  corCut = 0.1, permTimes = 1000, channel = T) {
	print("Load Gene Expression Data ...")
	if(geneExp == "TCGA"){
	  data(TCGA)
		data <- tcga_example
    	myavg <- apply(data, 1, mean, na.rm=T)
    	for(k in 1:ncol(data)) {
      		tmp <- data[,k]
      		tag <- is.na(tmp)
      		tmp[tag == 1] <- myavg[tag == 1] 
      		data[,k] <- tmp
    	}
	}else{
		data <- geneExp
	}
  	print("Gene Expression Data Loaded !")
  	print("Load Gene Set ...")
  	if(tarGene == "MSigDB"){
  	  data(MsigDB)
    	gset <- MsigDB_example
  	}else{
    	gset <- tarGene
  	}
  	print("Gene Set Loaded !")
  	max.iter <- iterativeMax #10
  	min.set <- setMin #20
  	cor.thr <- corCut #0.1
  	per.num <- permTimes #1000
  	comGen <- intersect(row.names(data), row.names(gset))
  	data <- data[comGen,]
  	gset <- gset[comGen,]
  	res <- matrix(0, nrow(gset), ncol(gset))
  	row.names(res) <- row.names(gset)
  	colnames(res) <- colnames(gset)
  	res <- as.data.frame(res)
  	reg <- gset
  	tmp <- apply(reg, 2, sum)
  	if(sum(tmp < min.set) > 0) {
   		tmp <- colnames(reg)[tmp < min.set]
    	res[, tmp] <- reg[, tmp]
    	tag <- !colnames(res) %in% tmp
    	reg <- reg[, tag == 1]
  	}
  	k <- 1
  	print ("Iteration start ...")
  	while(k <= max.iter) {
    	print (k)
    	old.reg <- reg
    	xx <- base5(data, reg, perm = per.num, median.norm = channel) #T
    	iras <- xx[[1]]
    	row.names(iras) <- colnames(data)
    	colnames(iras) <- colnames(reg)
    	for(i in 1 : ncol(iras)) {
    		tmp <- data[gset[, colnames(iras)[i]] == 1, ]
      		tmp <- cor(t(tmp), iras[,i], method = "s")
      		tmp <- row.names(tmp)[tmp > cor.thr]
      		reg[!(row.names(reg) %in% tmp), i] <- 0
    	}
    	tmp <- apply(reg, 2, sum)
    	if(sum(tmp < 20) > 0) {
    		tmpxx <- colnames(reg)[tmp < 20]
      		res[, tmpxx] <- reg[, tmpxx]
      		tag <- !(colnames(reg) %in% tmpxx)
      		if(sum(tag) == 0) break ## no gene set left
      		if(sum(tag) > 1) {
        		reg <- reg[, tag == 1]
        		old.reg <- old.reg[, tag==1]
      		}else{
        		reg <- reg[, tag == 1]
        		reg <- as.data.frame(reg, ncol = 1)
        		row.names(reg) <- row.names(old.reg)
        		colnames(reg) <- colnames(old.reg)[tag == 1]
        		old.reg <- old.reg[, tag == 1]
        		old.reg <- as.data.frame(old.reg, ncol = 1)
        		row.names(old.reg) <- row.names(reg)
        		colnames(old.reg) <- colnames(reg)
      		}
    	}
    	#find the target gene not change
    	tmp <- abs(old.reg - reg)
    	tmp <- apply(tmp, 2, sum)
    	if(sum(tmp == 0) > 0){
      		tmpxx <- colnames(reg)[tmp == 0]
      		res[, tmpxx] = reg[, tmpxx]
      		tag <- !(colnames(reg) %in% tmpxx)
      		if(sum(tag) == 0) break ## no gene set left
      		if(sum(tag) > 1) {
        		reg <- reg[, tag==1]
      		}else{
        		tmpy <- colnames(reg)[tag == 1]
        		tmpx <- row.names(reg)
        		reg <- reg[, tag == 1]
        		reg <- as.data.frame(reg, ncol = 1)
        		row.names(reg) <- tmpx
        		colnames(reg) <- tmpy
      		}
    	}
    	k <- k + 1
  	}
  	print ("Iteration end ...")
  	if(ncol(reg) > 0) {	
    	tmp <- colnames(reg)
    	res[, tmp] <- reg
  	}
  	tag <- apply(res, 2, sum)
  	res <- res[, tag >= min.set]
  	return (res)
}
